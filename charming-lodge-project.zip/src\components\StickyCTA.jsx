import React from 'react';
import { Phone, Calendar } from 'lucide-react';
import '../styles/StickyCTA.css';

const StickyCTA = () => {
    return (
        <div className="sticky-cta-mobile">
            <a href="https://wa.me/yournumber" target="_blank" rel="noreferrer" className="sticky-btn whatsapp">
                <Phone size={20} />
                <span>WhatsApp</span>
            </a>
            <a href="/suites" className="sticky-btn book">
                <Calendar size={20} />
                <span>Reservar</span>
            </a>
        </div>
    );
};

export default StickyCTA;

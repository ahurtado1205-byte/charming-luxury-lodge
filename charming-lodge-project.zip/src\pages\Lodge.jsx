import React from 'react';
import '../styles/Lodge.css';

const Lodge = () => {
    return (
        <div className="lodge-page">
            <section className="lodge-hero">
                <div className="hero-bg">
                    <img src="https://www.charming-bariloche.com/wp-content/uploads/2023/03/Foto-alojamiento-suites.jpg" alt="Lodge Exterior" />
                    <div className="hero-overlay"></div>
                </div>
                <div className="hero-content reveal">
                    <h1>La Esencia de Charming</h1>
                    <p>Un tributo a la Patagonia, esculpido en piedra y madera.</p>
                </div>
            </section>

            <section className="lodge-story container reveal">
                <div className="story-content">
                    <h2 className="section-title">Nuestra Filosofía</h2>
                    <p className="large-text">Charming no es solo un hotel; es un hogar diseñado para honrar el paisaje de Bariloche. Cada piedra, cada viga de madera y cada ventanal fue colocado con un propósito: integrar al huésped con la inmensidad del Nahuel Huapi.</p>
                    <div className="story-features">
                        <div className="s-feat">
                            <h3>Sustentabilidad</h3>
                            <p>Compromiso con la preservación del entorno boscoso.</p>
                        </div>
                        <div className="s-feat">
                            <h3>Privacidad</h3>
                            <p>Arquitectura descentralizada para asegurar la calma total.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="lodge-amenities">
                <div className="container">
                    <h2 className="section-title">Servicios Exclusivos</h2>
                    <div className="amenities-grid">
                        <div className="amenity reveal">
                            <img src="https://www.charming-bariloche.com/wp-content/uploads/2022/10/jacuzzi-roca-scaled.jpg" alt="Private Spa" />
                            <h3>Private Spa</h3>
                            <p>Sienta el lujo de tener su propio santuario de bienestar sin salir de su suite.</p>
                        </div>
                        <div className="amenity reveal">
                            <img src="https://www.charming-bariloche.com/wp-content/uploads/2022/09/gastronomia-gral.jpg" alt="Gastronomy" />
                            <h3>Gastronomía Stag</h3>
                            <p>El círculo que se cierra en su paladar con lo mejor de nuestra tierra.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Lodge;

import React from 'react';
import { Clock, Users, Utensils, MapPin } from 'lucide-react';
import '../styles/Stag.css';

const Stag = () => {
    return (
        <div className="stag-page">
            <section className="stag-hero">
                <div className="hero-bg">
                    <img src="https://www.charming-bariloche.com/wp-content/uploads/2023/03/CHARMING-Spot-12-Stag-20.jpg" alt="Stag Restaurant" />
                    <div className="hero-overlay"></div>
                </div>
                <div className="hero-content reveal">
                    <span className="stag-label">Gastronomía de Altura</span>
                    <h1>STAG</h1>
                    <p>Donde la Patagonia se encuentra con el fuego, frente a la inmensidad del lago.</p>
                    <a href="#reservar" className="btn btn-primary">Asegurar mi Mesa</a>
                </div>
            </section>

            <section className="stag-concept container reveal">
                <div className="concept-grid">
                    <div className="concept-text">
                        <h2 className="section-title" style={{ textAlign: 'left' }}>El círculo de los sentidos.</h2>
                        <p>En Stag, cada plato es un relato de nuestra tierra. Nuestra cocina es un tributo al producto local y a las estaciones, servido en un salón donde la madera noble y los ventanales infinitos crean una atmósfera de intimidad única.</p>
                        <p>No es solo una cena; es el momento donde el atardecer sobre el Nahuel Huapi se convierte en el ingrediente principal.</p>

                        <div className="stag-details">
                            <div className="s-detail">
                                <Clock size={20} />
                                <div>
                                    <strong>Momentos Stag</strong>
                                    <span>Desayuno, Almuerzo y Cenas de Autor</span>
                                    <span>Cena: 19:30 - 23:00</span>
                                </div>
                            </div>
                            <div className="s-detail">
                                <Users size={20} />
                                <div>
                                    <strong>Invitados</strong>
                                    <span>Una mesa abierta tanto para huéspedes como para amantes del buen vivir.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="concept-image">
                        <img src="https://www.charming-bariloche.com/wp-content/uploads/2022/09/gastronomia-gral.jpg" alt="Plato de autor Stag" />
                    </div>
                </div>
            </section>

            <section className="stag-menu-cta">
                <div className="container reveal">
                    <div className="menu-box">
                        <h2>Sinfonía Estacional</h2>
                        <p>Nuestra carta cambia con los ciclos de la naturaleza para garantizar la frescura absoluta de cada ingrediente.</p>
                        <div className="menu-btns">
                            <button className="btn btn-outline">Menú de Pasos</button>
                            <button className="btn btn-outline">Selección de Bodega</button>
                        </div>
                    </div>
                </div>
            </section>

            <section id="reservar" className="stag-reservation container reveal">
                <div className="reservation-grid">
                    <div className="res-card guests">
                        <h3>Huéspedes del Lodge</h3>
                        <p>Disfrute de la comodidad de integrar su experiencia gastronómica a su estadía. Mesas con vista al lago garantizadas para reservas internas.</p>
                        <button className="btn btn-primary">Vincular a mi Estadía</button>
                    </div>
                    <div className="res-card external">
                        <h3>Comensales Externos</h3>
                        <p>Venga a descubrir por qué Stag es el secreto mejor guardado de Bariloche. Recomendamos reservar con antelación para asegurar su vista al lago.</p>
                        <button className="btn btn-primary">Reserva Online</button>
                    </div>
                </div>
            </section>

            <section className="stag-location container reveal">
                <div className="location-info">
                    <MapPin size={40} className="pin" />
                    <h2>Un balcón al Nahuel Huapi</h2>
                    <p>Av. Bustillo Km 7.5. Un destino en sí mismo.</p>
                </div>
            </section>
        </div>
    );
};

export default Stag;

import React from 'react';
import { ShieldCheck, Clock, MapPin, Tag } from 'lucide-react';
import '../styles/TrustBar.css';

const TrustBar = () => {
    const items = [
        { icon: <Tag size={20} />, text: 'Mejor tarifa directa' },
        { icon: <ShieldCheck size={20} />, text: 'Cancelación flexible' },
        { icon: <Clock size={20} />, text: 'Atención inmediata' },
        { icon: <MapPin size={20} />, text: 'Ubicación privilegiada' }
    ];

    return (
        <div className="trust-bar">
            <div className="trust-bar-container">
                {items.map((item, index) => (
                    <div key={index} className="trust-item">
                        <span className="trust-icon">{item.icon}</span>
                        <span className="trust-text">{item.text}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TrustBar;

import React from 'react';
import TrustBar from '../components/TrustBar';
import { ArrowRight, Star, Quote } from 'lucide-react';
import '../styles/Home.css';

const Home = () => {
    const journeys = [
        {
            title: "Danza entre el Fuego y el Lago",
            desc: "Un paréntesis en el tiempo diseñado para el romance. Spa privado y cena degustación.",
            image: "https://www.charming-bariloche.com/wp-content/uploads/2022/10/Clasica-bano-2--scaled.jpg"
        },
        {
            title: "Familia en Armonía",
            desc: "Suites conectadas y actividades curadas frente al Nahuel Huapi.",
            image: "https://www.charming-bariloche.com/wp-content/uploads/2022/05/Suites-scaled.jpg"
        },
        {
            title: "Retiro de Inspiración",
            desc: "Donde las grandes ideas fluyen con la vista al lago.",
            image: "https://www.charming-bariloche.com/wp-content/uploads/2023/03/Foto-alojamiento-suites.jpg"
        }
    ];

    return (
        <div className="home-page">
            {/* Hero Section */}
            <section className="hero">
                <div className="hero-bg">
                    <img src="https://www.charming-bariloche.com/wp-content/uploads/2023/03/DSCN0001_10-scaled-1.jpg" alt="Charming Lodge Aerial View" />
                    <div className="hero-overlay"></div>
                </div>
                <div className="hero-content">
                    <span className="hero-award reveal">Elegido el Hotel más Romántico del Mundo 2024</span>
                    <h1 className="reveal">Donde el lago encuentra su calma, y usted la suya.</h1>
                    <p className="reveal">Sienta la inmensidad del Nahuel Huapi desde la intimidad de su suite con spa privado. Un refugio de lujo alpino diseñado para el reencuentro.</p>
                    <div className="hero-btns reveal">
                        <a href="/suites" className="btn btn-primary">Descubrir Suites</a>
                        <a href="/stag" className="btn btn-outline" style={{ borderColor: 'white', color: 'white' }}>Experiencia Stag</a>
                    </div>
                </div>
            </section>

            <TrustBar />

            {/* Intro Section */}
            <section className="intro container reveal">
                <div className="intro-grid">
                    <div className="intro-text">
                        <h2 className="section-title" style={{ textAlign: 'left' }}>La exclusividad de un spa privado en su propia habitación.</h2>
                        <p>En Charming, el bienestar no tiene horarios. Imagine sumergirse en un hidromasaje doble, disfrutar de un sauna seco o una ducha escocesa, todo bajo el calor de su propia chimenea y con la mirada perdida en el azul profundo del lago.</p>
                        <a href="/lodge" className="btn-text">Nuestra Filosofía de Bienestar <ArrowRight size={18} /></a>
                    </div>
                    <div className="intro-image">
                        <img src="https://www.charming-bariloche.com/wp-content/uploads/2022/10/8-1920.jpg" alt="Luxury Suite Private Spa" className="floating-img" />
                    </div>
                </div>
            </section>

            {/* Itineraries Section */}
            <section className="itineraries">
                <div className="container">
                    <h2 className="section-title">Momentos diseñados para el alma</h2>
                    <p className="section-subtitle">No es solo una estadía, es el mapa de sus recuerdos en la Patagonia.</p>

                    <div className="itinerary-grid">
                        {journeys.map((j, i) => (
                            <div key={i} className="itinerary-card reveal">
                                <div className="itinerary-img">
                                    <img src={j.image} alt={j.title} />
                                </div>
                                <div className="itinerary-info">
                                    <h3>{j.title}</h3>
                                    <p>{j.desc.replace("48 hs Románticas", "Una danza entre el fuego y el lago").replace("Desconexión total para dos", "Un paréntesis en el tiempo diseñado para el romance")}</p>
                                    <a href="/experiences" className="btn-link">Ver itinerario</a>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Stag Satellite Section */}
            <section className="stag-feature">
                <div className="stag-container">
                    <div className="stag-content reveal">
                        <span className="stag-label">Experiencia Gastronómica</span>
                        <h2 className="section-title" style={{ color: 'white' }}>STAG: Sabores que narran la Patagonia</h2>
                        <p>Una mesa frente al infinito. Fine dining de autor donde cada producto estacional rinde tributo a nuestra tierra, en un ambiente que celebra la calidez de la madera y el fuego.</p>
                        <div className="stag-btns">
                            <a href="/stag" className="btn btn-primary" style={{ backgroundColor: 'var(--accent)', color: 'var(--primary)' }}>Reservar Mesa</a>
                            <span className="stag-note">Prioridad para huéspedes del Lodge</span>
                        </div>
                    </div>
                    <div className="stag-visual">
                        <img src="https://www.charming-bariloche.com/wp-content/uploads/2023/03/CHARMING-Spot-12-Stag-20.jpg" alt="Stag Restaurant" />
                    </div>
                </div>
            </section>

            {/* Why Return / Social Proof */}
            <section className="testimonials container reveal">
                <h2 className="section-title">La huella de Charming en nuestros huéspedes</h2>
                <div className="testi-grid">
                    <div className="testi-card">
                        <Quote className="quote-icon" />
                        <p>"Ver el amanecer sobre el lago desde la cama, con el sonido del fuego crepitando de fondo, es algo que te cambia la perspectiva. Es el lujo de la paz absoluta."</p>
                        <div className="testi-author">
                            <span className="author-name">Clara Mendonça</span>
                            <span className="author-detail">Huésped Frecuente</span>
                        </div>
                    </div>
                    <div className="testi-card">
                        <Quote className="quote-icon" />
                        <p>"Stag no es solo comida, es el cierre perfecto del día. La atención es tan personalizada que terminas sintiendo que el restaurante fue abierto solo para vos."</p>
                        <div className="testi-author">
                            <span className="author-name">Ricardo G.</span>
                            <span className="author-detail">Experiencia Gourmet 2024</span>
                        </div>
                    </div>
                </div>
            </section>

            {/* Direct Booking Benefits */}
            <section className="direct-benefits">
                <div className="container">
                    <div className="benefits-box reveal">
                        <h3>Privilegios de la Casa</h3>
                        <p>Al reservar directamente con nosotros, accede a beneficios exclusivos que elevan su estadía.</p>
                        <div className="benefits-list">
                            <div className="benefit-item">
                                <Star size={18} />
                                <span>Late check-out de cortesía (sujeto a disp.)</span>
                            </div>
                            <div className="benefit-item">
                                <Star size={18} />
                                <span>Degustación de bienvenida en Stag</span>
                            </div>
                            <div className="benefit-item">
                                <Star size={18} />
                                <span>Acceso prioritario a masajes terapéuticos</span>
                            </div>
                        </div>
                        <a href="/suites" className="btn btn-primary">Consultar Disponibilidad</a>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;

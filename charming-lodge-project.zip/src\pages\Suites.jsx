import React, { useState } from 'react';
import { Check, Info, ArrowRight } from 'lucide-react';
import '../styles/Suites.css';

const suitesData = [
    {
        id: 1,
        name: "Charming Luxury Suite",
        type: "Matrimonial Premium",
        size: "70 m²",
        features: ["Vista frontal panorámica", "Private Spa (Sauna & Escocesa)", "Doble Hidromasaje", "Chimenea"],
        image: "https://www.charming-bariloche.com/wp-content/uploads/2022/10/8-1920.jpg",
        price: "Desde USD 480",
        spa: true
    },
    {
        id: 2,
        name: "Master Suite Superior",
        type: "Familia / Grupos",
        size: "130 m²",
        features: ["2 Dormitorios en suite", "Living con hogar a leña", "Cocina Gourmet", "Terraza al lago"],
        image: "https://www.charming-bariloche.com/wp-content/uploads/2022/06/Master-cama-2-scaled.jpg",
        price: "Desde USD 820",
        spa: true
    },
    {
        id: 3,
        name: "Classic Suite Lake View",
        type: "Matrimonial",
        size: "50 m²",
        features: ["Vista al lago y cerros", "Hidromasaje con ozonoterapia", "Deck privado", "Calidez alpina"],
        image: "https://www.charming-bariloche.com/wp-content/uploads/2022/05/Clasica-cama-1-1-scaled.jpg",
        price: "Desde USD 350",
        spa: false
    }
];

const Suites = () => {
    const [filter, setFilter] = useState('All');
    const [compareList, setCompareList] = useState([]);

    const filteredSuites = filter === 'All'
        ? suitesData
        : suitesData.filter(s => s.type.includes(filter) || (filter === 'Spa' && s.spa));

    const toggleCompare = (suite) => {
        if (compareList.find(s => s.id === suite.id)) {
            setCompareList(compareList.filter(s => s.id !== suite.id));
        } else if (compareList.length < 2) {
            setCompareList([...compareList, suite]);
        }
    };

    return (
        <div className="suites-page">
            <section className="suites-hero">
                <div className="container reveal">
                    <h1 className="section-title">El Refugio de sus Sueños</h1>
                    <p className="section-subtitle">Donde cada Suite es un santuario privado. Despierte frente al Nahuel Huapi y disfrute del calor del hogar en la intimidad de su propio spa.</p>
                </div>
            </section>

            <section className="suites-filter container">
                <div className="filter-btns">
                    <button onClick={() => setFilter('All')} className={filter === 'All' ? 'active' : ''}>Todas</button>
                    <button onClick={() => setFilter('Matrimonial')} className={filter === 'Matrimonial' ? 'active' : ''}>Parejas</button>
                    <button onClick={() => setFilter('Familia')} className={filter === 'Familia' ? 'active' : ''}>Familias</button>
                    <button onClick={() => setFilter('Spa')} className={filter === 'Spa' ? 'active' : ''}>Con Spa Privado</button>
                </div>
            </section>

            <section className="suites-list container">
                <div className="suites-grid">
                    {filteredSuites.map(suite => (
                        <div key={suite.id} className="suite-card reveal">
                            <div className="suite-img">
                                <img src={suite.image} alt={suite.name} />
                                <div className="suite-price">{suite.price}<span>/noche</span></div>
                            </div>
                            <div className="suite-info">
                                <h3>{suite.name}</h3>
                                <div className="suite-meta">
                                    <span>{suite.type}</span> • <span>{suite.size}</span>
                                </div>
                                <ul className="suite-features">
                                    {suite.features.map((f, i) => (
                                        <li key={i}><Check size={14} /> {f}</li>
                                    ))}
                                </ul>
                                <div className="suite-actions">
                                    <button className="btn btn-primary">Reservar ahora</button>
                                    <button
                                        className={`btn-compare ${compareList.find(s => s.id === suite.id) ? 'active' : ''}`}
                                        onClick={() => toggleCompare(suite)}
                                    >
                                        {compareList.find(s => s.id === suite.id) ? 'En comparador' : 'Comparar'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {compareList.length > 0 && (
                <div className="comparator-drawer">
                    <div className="comparator-container">
                        <h4>Comparador de Suites ({compareList.length}/2)</h4>
                        <div className="compare-grid">
                            {compareList.map(s => (
                                <div key={s.id} className="compare-item">
                                    <span>{s.name}</span>
                                    <button onClick={() => toggleCompare(s)}>×</button>
                                </div>
                            ))}
                            {compareList.length === 2 && (
                                <button className="btn btn-accent btn-sm">Ver Comparativa</button>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Comparison Modal (Simple version) */}
            {compareList.length === 2 && (
                <section className="comparison-table container reveal">
                    <h2 className="section-title">Diferencias clave</h2>
                    <div className="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Característica</th>
                                    <th>{compareList[0].name}</th>
                                    <th>{compareList[1].name}</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Tamaño</td>
                                    <td>{compareList[0].size}</td>
                                    <td>{compareList[1].size}</td>
                                </tr>
                                <tr>
                                    <td>Spa Privado</td>
                                    <td>{compareList[0].spa ? <Check color="green" /> : 'No'}</td>
                                    <td>{compareList[1].spa ? <Check color="green" /> : 'No'}</td>
                                </tr>
                                <tr>
                                    <td>Tarifa base</td>
                                    <td>{compareList[0].price}</td>
                                    <td>{compareList[1].price}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </section>
            )}
        </div>
    );
};

export default Suites;

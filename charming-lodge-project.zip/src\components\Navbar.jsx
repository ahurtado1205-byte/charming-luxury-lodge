import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Calendar } from 'lucide-react';
import '../styles/Navbar.css';

const Navbar = () => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const location = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        setIsMenuOpen(false);
    }, [location]);

    return (
        <nav className={`navbar ${isScrolled ? 'scrolled' : ''} ${isMenuOpen ? 'open' : ''}`}>
            <div className="navbar-container">
                <div className="nav-toggle" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                    {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </div>

                <Link to="/" className="nav-logo">
                    <span className="logo-main">CHARMING</span>
                    <span className="logo-sub">LUXURY LODGE & PRIVATE SPA</span>
                </Link>

                <div className={`nav-links ${isMenuOpen ? 'active' : ''}`}>
                    <Link to="/lodge" className="nav-link">El Lodge</Link>
                    <Link to="/suites" className="nav-link">Suites</Link>
                    <Link to="/experiences" className="nav-link">Experiencias</Link>
                    <Link to="/stag" className="nav-link">Stag Restaurant</Link>
                    <Link to="/offers" className="nav-link">Ofertas</Link>

                    <div className="nav-actions-mobile">
                        <Link to="/contact" className="btn btn-primary">Reservar</Link>
                    </div>
                </div>

                <div className="nav-actions">
                    <a href="https://wa.me/yournumber" target="_blank" rel="noreferrer" className="nav-icon-link">
                        <Phone size={20} />
                        <span className="hide-mobile">WhatsApp</span>
                    </a>
                    <Link to="/suites" className="btn btn-primary">
                        <Calendar size={18} style={{ marginRight: '8px' }} />
                        <span className="hide-mobile">Reservar</span>
                    </Link>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;

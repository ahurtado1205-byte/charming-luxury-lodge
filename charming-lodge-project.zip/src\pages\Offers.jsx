import React from 'react';
const Offers = () => (
    <div style={{ paddingTop: '150px', minHeight: '80vh' }} className="container">
        <h1 className="section-title">Ofertas Especiales</h1>
        <p className="section-subtitle">Beneficios exclusivos para quienes reservan directo.</p>
        <div className="itinerary-grid">
            <div className="itinerary-card">
                <div className="itinerary-info">
                    <h3>Pre-Winter 2026</h3>
                    <p>Reserve antes del 30 de Mayo y obtenga un 20% de descuento y upgrade de suite sujeto a disponibilidad.</p>
                    <button className="btn btn-primary">Aplicar Oferta</button>
                </div>
            </div>
            <div className="itinerary-card">
                <div className="itinerary-info">
                    <h3>Stay & Dine</h3>
                    <p>Mínimo 3 noches. Incluye una cena de pasos en Stag de regalo.</p>
                    <button className="btn btn-primary">Ver Disponibilidad</button>
                </div>
            </div>
        </div>
    </div>
);
export default Offers;
